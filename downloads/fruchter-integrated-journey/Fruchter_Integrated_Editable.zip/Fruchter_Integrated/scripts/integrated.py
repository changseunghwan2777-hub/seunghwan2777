"""Diagrammatic lineage; geometry is read from the previous study snapshots."""
import final as F
from final import *
from shapely.geometry import shape as from_geojson
from shapely.affinity import scale
import base64

S=json.loads((ROOT/'source/rotation-study.json').read_text())
CY=json.loads((ROOT/'source/courtyard-study.json').read_text())
RS=json.loads((ROOT/'source/rule-study.json').read_text())
MODELS={m['id']:m for m in RS['models']}
FIELDS={k:json.loads((ROOT/'source'/f'field-{k}.json').read_text()) for k in ['uniform','regular','clusters']}
OG={k:scale(Polygon(v),yfact=-1,origin=(0,0)) for k,v in S['original']['regions'].items()}
OG_FRAME=unary_union(list(OG.values())).envelope
COLS={'A':'#BBC6D7','B':'#DBD4CB','C':'#CBD6D1','D':'#E5B5C5','E':'#FAF1F4'}
MF=unary_union([decode(m['envelope']) for m in RS['models']]).envelope

def head(b,n,title,subtitle):
 b.layer('00_Titles');b.text(18,17,'FRUCHTER HOUSE / FROM ORIGINAL SKETCH TO SHARED GROUND',8.4,'EN',MUTED)
 b.text(576,17,f'{n:02d} / 15',10,'EN',MAGENTA,'end')
 b.text(18,34,title,29,'EN',INK);b.text(18,46,subtitle,11,'KR',INK)
 b.line((18,55),(576,55),'#BFC4CC',.2)

def foot(b,note='원본에 대한 해석과 새로운 설계 조작을 구분한 과정 도면 / 실측 축척 미확정.'):
 b.layer('99_Footer');b.line((18,406),(576,406),'#D5D8DD',.18)
 b.text(18,414,note,7.0,'KR',MUTED);b.text(576,414,'A2 / 594 × 420 mm / NTS',7.1,'EN',MUTED,'end')

def original_image(b,x,y,w,h):
 data=base64.b64encode((ROOT/'assets/original-page-render.png').read_bytes()).decode()
 el(b.g,'image',x=x,y=y,width=w,height=h,preserveAspectRatio='xMidYMid meet',href='data:image/png;base64,'+data)

def sourceplan(b,T,labels=False):
 for k,g in OG.items():
  drawgeom(b,g,T,COLS[k],NAVY,.22 if k in 'ABC' else .12)
  if labels:
   x,y=T(g.representative_point().coords[0]);b.text(x,y+1.3,k,14,'EN',NAVY,'middle')
 if labels:
  for k in 'ABC':
   p=OG[k].centroid.coords[0];q=OG['D'].centroid.coords[0];b.arrow([T(p),T(q)],'#737E91',.25,1.6)

def rot_regions(v):return {k:scale(Polygon(ps),yfact=-1,origin=(0,0)) for k,ps in v['regions'].items()}
def olddecode(v):return scale(decode(v),yfact=-1,origin=(0,0))
def model(b,m,T,void=True):
 drawgeom(b,decode(m['envelope']),T,'#D8DEE7',NAVY,.14)
 for g in m['regions'].values():drawgeom(b,decode(g),T,None,NAVY,.14)
 for g in m['double'].values():drawgeom(b,decode(g),T,ROSE)
 drawgeom(b,decode(m['triple']),T,'#FFF' if void else MAGENTA,NAVY,.14)

def overview():
 b=Board('01_Complete_Journey');head(b,1,'FROM SKETCH TO SHARED GROUND','미실현 주택의 공간 관계를 읽고, 회전과 중첩의 규칙을 거쳐 하나의 공용 바닥으로 발전시킨다.')
 titles=['원본 스케치','공간군 추출','회전과 틈','중정의 두 방법','규칙적 중첩','모듈 반복','독립 중심의 변화','내부 정리와 최종본']
 desc=['Louis I. Kahn / Fruchter House, 1951. 제공된 원본 이미지를 출발점으로 읽는다.','A·B·C의 독립된 방향, D의 연결 중심, E의 진입 관계를 해석한다.','중심의 모양보다 공간군의 방향 관계를 바꾸어 틈을 다양화한다.','벌려서 얻는 마당과, 겹치는 부분을 비워 얻는 중정을 비교한다.','120° 배치와 공통 15° 회전. 세 날개의 삼중 중첩을 비워 M4를 만든다.','세 날개를 하나의 모듈로 묶어 반복한다. 공용 오피스로 용도를 전환한다.','20개 모듈이 각자의 중심에서 이동·회전한다. 같은 규칙 안에 차이를 만든다.','단일 배치를 유지한 채 내부 9곳만 정리. 검정·선·색의 세 지도로 읽는다.']
 for i in range(8):
  x=18+(i%4)*142;y=72+(i//4)*160;b.text(x,y,f'{i+1:02d}',10,'EN',MAGENTA)
  frame=(x,y+10,130,88)
  if i==0:original_image(b,*frame)
  elif i==1:sourceplan(b,fit(OG_FRAME,*frame),True)
  elif i==2:
   regs=rot_regions(S['variants'][2]);T=fit(unary_union(list(regs.values())),*frame)
   for k,g in regs.items():drawgeom(b,g,T,COLS[k],NAVY,.16)
  elif i==3:
   alt=CY['alternatives']['B'];T=fit(olddecode(alt['envelope']),*frame);drawgeom(b,olddecode(alt['floor']),T,NAVY);drawgeom(b,olddecode(alt['void']),T,None,MAGENTA,.25)
  elif i==4:model(b,MODELS['M4'],fit(MF,*frame))
  elif i==5:
   g=from_geojson(FIELDS['uniform']['floor']);drawgeom(b,g,fit(g,*frame),NAVY)
  elif i==6:drawgeom(b,OLD,fit(OLD,*frame),NAVY)
  else:F.colorplot(b,fit(OLD,*frame))
  b.layer('Step_text_'+str(i));b.text(x,y+109,titles[i],12);b.wrap(x,y+120,desc[i],130,9,5)
  if i%4<3:b.arrow([(x+132,y+55),(x+139,y+55)],'#A1A8B3',.22,1.2)
 b.text(18,396,'원본 → 해석 → 설계 실험 → 선택 → 반복 → 수정 → 최종 표현',12,'KR',NAVY)
 foot(b,'원본 이미지: 사용자 제공 「1106 장승환 표현기법 발표자료」 2쪽. 축척이 다른 단계를 개별 맞춤 크기로 요약.');b.save()

def source_reading():
 b=Board('02_Reading_Kahn');head(b,2,'READ THE RELATIONS','원본의 불완전한 선을 완성된 사실로 단정하지 않고, 공간 사이의 관계를 추출한다.')
 b.text(18,70,'01 / PROVIDED ORIGINAL SKETCH',10,'EN',NAVY);original_image(b,18,79,263,211)
 b.text(310,70,'02 / INTERPRETIVE EXTRACTION',10,'EN',NAVY);sourceplan(b,fit(OG_FRAME,310,79,266,211),True)
 b.text(18,302,'Louis I. Kahn · Fruchter House · 1951',12,'EN',NAVY)
 b.text(310,302,'A 개별실군 / B 공유실군 / C 식사·서비스군',9.5)
 b.text(310,312,'D 연결 중심 / E 진입 마당',9.5)
 cards=[('보이는 관계','서로 다른 방향의 세 공간군과 그 사이의 연결 여지, 외부에서 진입하는 전이 관계를 읽는다.'),('연구자의 해석','A·B·C·D·E는 공간을 분석하기 위한 구분이다. 세부 기능과 D의 지붕·개방 여부는 확정하지 않는다.'),('이어받을 원리','형태를 그대로 복제하기보다 공간군의 독립성, 방향의 차이, 사이의 관계를 이후 조작의 기준으로 삼는다.')]
 for i,(t,txt) in enumerate(cards):
  x=18+188*i;b.line((x,329),(x+176,329),'#CCD1D8',.2);b.text(x,342,t,12);b.wrap(x,354,txt,174,10,6)
 foot(b,'이미지 출처: 사용자 발표자료 1106, 2쪽. 추출선은 이전 A3 해석 모델을 계승한 비례 연구이며 원본 실측 도면이 아니다.');b.save()

def strategy():
 b=Board('03_Strategy_Shift');head(b,3,'ROTATION → INTERSTICE','Centrality를 별도의 중심 형태 만들기에서, 관계 변화가 만들어내는 결과로 다시 읽는다.')
 for x,t,color,body in [(18,'CENTRALITY','#939AA5','초기: 중심과 연결에 주목'),(210,'ROTATION',NAVY,'우선 조작: 방향 관계의 변화'),(402,'INTERSTICE',MAGENTA,'핵심 성과: 틈의 다양화와 활성화')]:
  b.text(x,83,t,21,'EN',color);b.text(x,96,body,10)
 b.arrow([(359,81),(390,81)],MAGENTA,.45,2)
 variants=S['variants'];frame=unary_union([g for v in variants for g in rot_regions(v).values()]).envelope
 for i,v in enumerate(variants):
  x=18+142*i;T=fit(frame,x,123,130,145)
  for k,g in rot_regions(v).items():drawgeom(b,g,T,COLS[k],NAVY,.20)
  for pair,metric in v['gap_metrics'].items():
   ps=[(px,-py) for px,py in metric['nearest_segment']];strokegeom(b,LineString(ps),T,MAGENTA,.55)
  b.text(x,286,v['id']+' / '+['회전 전 비교 기준','작은 각도차','서로 다른 틈','큰 각도차'][i],11)
  b.text(x,298,' / '.join(f'{k} {v["angles"][k]:+g}°' for k in 'ABC'),8.5,'EN',NAVY)
  b.wrap(x,312,['이격을 고정한 비교 기준. 이후 회전에 따른 관계 변화만 읽는다.','접점과 마주 보는 방향이 조금씩 바뀐다.','AB의 열림과 CA의 압축이 달라진다. 당시의 도서관·공유작업실 연구에 채택.','회전이 크다고 모든 틈이 넓어지는 것은 아니다.'][i],130,9.5,5.5)
 b.text(18,345,'R0–R3 각도 부호: +는 도면상 시계 방향. 이후 M4의 수학 좌표계와 부호 기준이 다르다.',8.3,'KR',MUTED)
 b.line((18,354),(576,354),'#D5D8DD',.2)
 b.wrap(18,370,'전략의 수정: 중앙을 다른 다각형으로 바꾸는 대신, 주변 공간군을 움직여 진입·시선·거리·경계가 달라지는 이유를 드러낸다.',550,12,7)
 foot(b,'출처: 1023 발표 3–6쪽, 1106 발표 7·9쪽 및 회전 연구 R0–R3 좌표. 같은 방향·축척. 마젠타는 최단거리이며 유효 통로폭이 아니다.');b.save()

def courtyard():
 b=Board('04_Two_Ways_To_Empty');head(b,4,'EXPAND / OVERLAP / CARVE','기존 사이 공간을 벌리는 방법과, 겹침을 비워 내부 중정을 만드는 방법을 함께 검토한다.')
 frame=unary_union([OG_FRAME]+[olddecode(a['envelope']) for a in CY['alternatives'].values()]).envelope
 for row,key in enumerate(['A','B']):
  alt=CY['alternatives'][key];y=76+156*row
  b.text(18,y+12,key,26,'EN',MAGENTA);b.text(18,y+25,'벌림' if key=='A' else '중첩',14)
  b.wrap(18,y+40,'바깥으로 벌려 사이 공간을 키운다.' if key=='A' else '안쪽으로 접속해 교집합을 만든다.',75,10,6)
  for step in range(3):
   x=118+157*step;T=fit(frame,x,y+4,145,101)
   if step==0:
    for k in 'ABC':drawgeom(b,OG[k],T,COLS[k],NAVY,.18)
   elif step==1:
    for k,g in alt['regions'].items():drawgeom(b,olddecode(g),T,COLS[k],NAVY,.18)
    if key=='B':drawgeom(b,olddecode(alt['overlap']),T,ROSE)
   else:
    drawgeom(b,olddecode(alt['floor']),T,NAVY)
    drawgeom(b,olddecode(alt['shared']),T,ROSE)
    drawgeom(b,olddecode(alt['void']),T,'#FFF',MAGENTA,.28)
   label=['추출한 세 공간군','회전·이격으로 관계 조절','마당과 연결 영역을 구분'][step]
   b.text(x,y+119,label,10)
   if step<2:b.arrow([(x+145,y+58),(x+153,y+58)],'#A5ACB6',.22,1.2)
 b.line((18,367),(576,367),'#D5D8DD',.2)
 b.wrap(18,380,'벌림은 큰 마당을 얻지만 외곽을 확장한다. 중첩은 안쪽의 비움을 얻지만 실내 면적을 줄인다. 겹침을 전부 삭제하면 연결이 끊기므로, 무엇을 비우고 무엇을 남길지 규칙이 필요해졌다.',550,10.5,6)
 foot(b,'출처: 중정 확장·중첩 연구 A/B 저장 좌표, 1106 발표 10–13쪽. 모든 비교도는 같은 축척. 색과 새 경계는 당시의 설계 제안.');b.save()

def model_families():
 b=Board('05_Overlap_Families');head(b,5,'GIVE OVERLAP A RULE','우연한 겹침을 넘어, 설명하고 반복할 수 있는 기하 규칙을 비교한다.')
 names=['동심 회전','연쇄 연결','대칭 방사','동일 위상 회전','둘레 순환']
 reasons=['중앙 삼중 영역이 커져 비우면 실내 손실이 크다.','연결이 선형으로 이어져 세 방향 순환이 약하다.','공유 접점이 넓지만 장축이 중심을 향한다.','세 접점의 규칙성을 유지하며 장축이 비껴 만난다.','면적 보존에 유리하나 삼중 중첩을 비우는 주제와 다르다.']
 for i,m in enumerate(RS['models']):
  x=18+113*i
  if m['id']=='M4':b.rect(x-3,65,110,222,'#FBF1F5',None)
  b.text(x,77,m['id']+' / '+names[i],11)
  T=fit(MF,x,92,104,120);model(b,m,T,False)
  b.text(x,226,m['rule'],8)
  b.wrap(x,240,reasons[i],103,9.5,5.5)
 b.line((18,302),(576,302),'#D5D8DD',.2)
 for i,key in enumerate(['M3','M4','M5']):
  x=18+188*i;m=MODELS[key];T=fit(MF,x,315,83,75);model(b,m,T)
  b.text(x+91,326,key+(' / 채택' if key=='M4' else ' / 비교'),11,'KR',MAGENTA if key=='M4' else NAVY)
  b.wrap(x+91,340,['넓은 접합의 장점. 중심으로 향하는 위계가 강함.','반복 가능한 세 공유 접점과 중앙 비움을 함께 확보.','자연 발생 중정의 장점. 삭제 조작 없이 비움이 생김.'][i],84,9.5,5.5)
 foot(b,'출처: 규칙 기반 중첩 연구 M1–M5. 공통 직사각형·동일 축척. 상단 마젠타는 삼중 영역, 하단은 그 영역을 비운 결과.');b.save()

def module_construction():
 b=Board('06_From_Groups_To_Module');head(b,6,'MAKE THE MODULE EXPLICIT','원형의 방향 관계는 이어받고, 반복을 위한 공통 기하로 바꾸는 지점을 명시한다.')
 # Compare the same-area normalized original outlines with the explicit new rectangle.
 source_unit=RS['regularisation']['source_coordinate_units_per_u'];regs={k:scale(g,xfact=1/source_unit,yfact=1/source_unit,origin=(0,0)) for k,g in OG.items() if k in 'ABC'}
 local=[]
 for k,g in regs.items():
  coords=list(g.exterior.coords);edge=max(zip(coords[:-1],coords[1:]),key=lambda ab:math.dist(*ab));ang=math.degrees(math.atan2(edge[1][1]-edge[0][1],edge[1][0]-edge[0][0]));local.append(rotate(translate(g,-g.centroid.x,-g.centroid.y),-ang,origin=(0,0)))
 common=box(-.625,-.4,.625,.4);localframe=unary_union(local+[common]).envelope
 for i,g in enumerate(local):
  x=18+i*58;T=fit(localframe,x,83,51,51);drawgeom(b,g,T,COLS['ABC'[i]],NAVY,.2);b.text(x+25,145,'ABC'[i],10,'EN',NAVY,'middle')
 b.arrow([(191,110),(217,110)],MAGENTA,.35,2)
 T=fit(localframe,245,83,51,51);drawgeom(b,common,T,'#D9DFE8',NAVY,.25);b.text(229,145,'1.25u × 0.80u',11,'EN',NAVY)
 b.text(342,84,'REGULARISATION / 설계 가설',14)
 b.wrap(342,99,'세 공간군의 합계 면적은 유지하지만 개별 외곽·종횡비·면적은 달라진다. M4는 칸의 원본 평면을 그대로 회전시킨 형태가 아니다.',231,10.5,6)
 b.text(342,136,'A −1.25% / B +2.82% / C −1.46%',10,'EN',MAGENTA)
 b.line((18,165),(576,165),'#D5D8DD',.2)
 steps=[MODELS['M3'],MODELS['M4'],MODELS['M4'],RS['original_outline_check']]
 titles=['120° 간격의 세 중심','공통 15° 위상 회전','삼중 중첩만 비우기','원래 외곽 재적용 검토']
 for i,m in enumerate(steps):
  x=18+i*142;T=fit(MF,x,191,130,130);model(b,m,T,void=i>=2)
  if i<2:
   for p in m['centres'].values():b.cross(*T(p),1,NAVY,.18)
  b.text(x,180,f'0{i+1}',10,'EN',MAGENTA);b.text(x,338,titles[i],11)
  b.wrap(x,351,['R = 0.45u. 중심의 간격을 동일하게 설정한다.','세 장축에 같은 회전량을 더한다. 접점은 회전 대칭을 유지한다.','세 공유 접점은 남기고 가운데 삼중 영역을 중정으로 만든다.','원래 비정형 외곽에 같은 규칙을 적용하면 중정이 약 82% 작아진다.'][i],130,9.5,5.5)
 foot(b,'출처: 정규화·원형 재적용 연구. 상단은 중심 정렬된 원래 외곽과 공통 모듈, 하단은 동일 축척. u는 상대 단위.');b.save()

def choose_parameters():
 b=Board('07_Parameters_And_Voids');head(b,7,'CHOOSE THE ROTATION AND THE VOID','회전량과 중심 반경을 비교한 뒤, 실내 연결을 유지하는 비움 규칙을 선택한다.')
 b.text(18,73,'01 / R × φ : NINE GEOMETRIC TESTS',11,'EN',NAVY)
 for i,m in enumerate(RS['parameter_grid']):
  x=18+(i%3)*91;y=88+(i//3)*93
  selected=abs(m['radius']-.45)<1e-5 and m['phase']==15
  if selected:b.rect(x-2,y-5,88,88,'#FBEDF3',MAGENTA,.3)
  model(b,m,fit(MF,x,y,83,65))
  b.text(x,y+78,f'R {m["radius"]:.2f}u / φ {m["phase"]}°',8.5,'EN',MAGENTA if selected else NAVY)
 b.text(310,73,'02 / WHAT IS REMOVED?',11,'EN',NAVY)
 titles=['모두 남김','모든 겹침 제거','이중 겹침만 제거','삼중 겹침만 제거']
 bodies=['중앙의 실내 위계가 강함.','공유 접점도 사라져 분리.','세 공간군과 중앙이 분리.','공유 접점 + 열린 중정.']
 for i,p in enumerate(RS['void_policies']):
  x=310+(i%2)*139;y=89+(i//2)*131
  if i==3:b.rect(x-3,y-6,131,123,'#FBEDF3',MAGENTA,.3)
  T=fit(MF,x,y,124,83);drawgeom(b,decode(p['floor']),T,NAVY)
  b.text(x,y+96,titles[i],10);b.text(x,y+108,bodies[i],8.7)
 b.line((18,368),(576,368),'#D5D8DD',.2)
 b.wrap(18,381,'선정: R 0.45u + 공통 15° 회전 + 삼중 중첩 삭제. 이는 가장 큰 접점이나 가장 많은 면적을 얻는 최적안이 아니라, 세 접점의 동등성과 중앙 비움을 함께 드러내기 위한 판단이다.',548,10.5,6)
 foot(b,'출처: 규칙 기반 중첩 연구의 9개 파라미터 조합·4개 비움 정책. 각 비교 묶음은 동일 축척. 실제 치수·성능 최적화가 아니다.');b.save()

def field_history():
 b=Board('08_Repetition_And_Revision');head(b,8,'REPEAT, TEST, RETURN, REFINE','군집을 새로 나누는 대신, 연속 회전장의 전체 배치로 돌아와 내부 경계만 정리한다.')
 gs=[from_geojson(FIELDS['uniform']['floor']),OLD,from_geojson(FIELDS['regular']['floor']),from_geojson(FIELDS['clusters']['floor'])]
 frame=unary_union(gs+[FLOOR]).envelope
 titles=['균일 반복 / 12개','연속 회전장 / 20개','제한 각도 격자 / 19개','군집 분리 / 18개']
 notes=['반복 규칙은 읽히지만 같은 것을 붙여 놓은 인상이 강함.','각 중심이 같은 함수에 다르게 반응. 최종적으로 복귀한 배치.','접점의 규칙성은 강화되지만 사잇간격이 좁다는 피드백.','빈 공간은 커지지만 단일 배치를 유지하려는 목표에서 벗어남.']
 for i,g in enumerate(gs):
  x=18+i*142;T=fit(frame,x,86,130,112);drawgeom(b,g,T,NAVY)
  b.text(x,73,f'0{i+1}',10,'EN',MAGENTA);b.text(x,218,titles[i],10.5);b.wrap(x,230,notes[i],130,9.5,5.5)
 b.line((18,272),(576,272),'#D5D8DD',.2)
 T=fit(OLD,18,291,137,103);drawgeom(b,FLOOR,T,NAVY)
 b.text(177,292,'RETURN TO ONE FIELD',17,'EN',MAGENTA)
 b.wrap(177,308,'승인된 20개 모듈의 위치·회전각·외곽으로 복귀. 내부 9곳의 돌출부만 정리해 하나의 바닥과 31개 비움을 유지한다.',181,10,6)
 b.text(177,365,'다음 7쪽: 최종안의 생성·정리·표현',10)
 b.text(389,292,'TWO SCALES OF OVERLAP',15,'EN',NAVY)
 b.wrap(389,308,'모듈 안: 세 날개의 삼중 중첩을 비워 중정으로.\n모듈 사이: 반복된 모듈의 겹침을 남겨 공유 영역으로.',183,10,6)
 b.text(389,359,'주거 원형 → 도서관·작업소 검토 → 공용 오피스',9)
 b.wrap(389,372,'최종 용도는 공용 오피스 가설. 기존 주택의 용도를 그대로 확정한 것이 아니다.',183,9,5)
 foot(b,'이전 검토안은 모두 저장된 실제 좌표로 재도식화. 위 네 배치는 같은 방향·축척. 최종 배치의 모듈은 새로 움직이지 않았다.');b.save()

FRONT=[overview,source_reading,strategy,courtyard,model_families,module_construction,choose_parameters,field_history]

class FinalBoard(Board):
 def __init__(self,name):
  if name[:2].isdigit():name=f'{int(name[:2])+8:02d}'+name[2:]
  super().__init__(name)

def finish():
 F.Board=FinalBoard
 F.head=lambda b,n,title,kr:head(b,n+8,title,kr)
 oldfoot=F.foot
 F.foot=lambda b,note='설계 스터디 / u는 상대 단위 / 실제 치수·구조·층고는 확정하지 않음.':oldfoot(b,note.replace('04–06','12–14'))
 F.process();F.rule();F.cleanup_board()
 for mode in ['black','line','color']:F.hero(mode)
 F.office()

if __name__=='__main__':
 import sys
 F.audit()
 for fn in FRONT:fn()
 if '--front-only' not in sys.argv:finish()
