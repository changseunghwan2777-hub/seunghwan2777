from pathlib import Path
import json,hashlib,zipfile,shutil,xml.etree.ElementTree as ET
import fitz
from PIL import Image,ImageDraw,ImageChops
from graphics import FM,NS

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
pages=sorted(OUT.glob('[0-9][0-9]_*.pdf'));assert len(pages)==15
doc=fitz.open();checks=[]
for i,p in enumerate(pages):
 with fitz.open(p) as src:
  assert len(src)==1
  pg=src[0];size=[pg.rect.width*25.4/72,pg.rect.height*25.4/72]
  assert abs(size[0]-594)<.01 and abs(size[1]-420)<.01
  rasters=len(pg.get_images());assert rasters==(1 if i<2 else 0),(p.name,rasters)
  doc.insert_pdf(src);checks.append({'page':i+1,'file':p.name,'size_mm':size,'raster_image_count':rasters})
doc.set_metadata({'title':'Fruchter House — From Original Sketch to Shared Ground','author':'장승환 / 공간 재구성 연구','subject':'원본 해석부터 회전·중첩·정규화·반복·내부 정리와 최종 공용 오피스까지','keywords':'Louis I. Kahn, Fruchter House, rotation, interstice, figure-ground'})
doc.set_toc([[1,f'{i+1:02d} '+p.stem[3:].replace('_',' '),i+1] for i,p in enumerate(pages)])
pdf=ROOT/'Fruchter_Integrated_Journey_A2.pdf'
if pdf.exists():pdf.unlink()
doc.save(pdf,garbage=4,deflate=True)
shutil.copy2(pages[0],ROOT/'Fruchter_Journey_Overview_A2.pdf')
sheet=Image.new('RGB',(2100,2550),'#E8EAED');draw=ImageDraw.Draw(sheet)
for i,page in enumerate(doc):
 pix=page.get_pixmap(matrix=fitz.Matrix(700/page.rect.width,700/page.rect.width),alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
 x=i%3*700;y=i//3*510;sheet.paste(im,(x,y));draw.text((x+10,y+497),pages[i].stem,fill='#283858')
sheet.save(ROOT/'Fruchter_Integrated_Contact_Sheet.png');doc.close()
for p in OUT.glob('*.svg'):
 root=ET.parse(p).getroot();ids=[n.get('id') for n in root.iter() if n.get('id')];assert len(ids)==len(set(ids)),p
 for t in root.iter('{'+NS+'}text'):
  assert all(ord(c) in FM[t.get('data-font','KR')]['cmap'] for c in t.text or ''),(p,t.text)
for p in (ROOT/'review').glob('*text-bounds.json'):
 for t in json.loads(p.read_text()):assert t['left']>=17.9 and t['right']<=576.1 and t['baseline']<=414.1,(p,t)
report={'pages':checks,'glyphs_checked':True,'unique_svg_ids':True,'text_inside_margins':True,'source_image_pages':[1,2],'geometry':json.loads((ROOT/'design/validation.json').read_text())}
(ROOT/'design/integrated-export-checks.json').write_text(json.dumps(report,indent=2))
files=[]
for folder in ['scripts','assets','source','design','output']:
 files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.extend(ROOT/n for n in ['README.md','DESIGN_PHILOSOPHY.md','requirements.txt','Fruchter_Integrated_Journey_A2.pdf','Fruchter_Journey_Overview_A2.pdf','Fruchter_Integrated_Contact_Sheet.png'])
manifest={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)}
(ROOT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2));files.append(ROOT/'MANIFEST.json')
archive=ROOT/'Fruchter_Integrated_Editable.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,'Fruchter_Integrated/'+str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'pages':15,'pdf_bytes':pdf.stat().st_size,'zip_bytes':archive.stat().st_size,'files_in_zip':len(files)}))
