"""Assemble the seven-page A2 book and portable editable package."""
from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
import fitz
from PIL import Image,ImageDraw
from graphics import FM,NS

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output'
PAGES=sorted(OUT.glob('[0-9][0-9]_*.pdf'))
assert len(PAGES)==7
doc=fitz.open();checks=[]
for p in PAGES:
 with fitz.open(p) as src:
  assert len(src)==1
  page=src[0];mm=[page.rect.width*25.4/72,page.rect.height*25.4/72]
  assert abs(mm[0]-594)<.01 and abs(mm[1]-420)<.01
  assert not page.get_images()
  checks.append({'page':p.name,'millimetres':mm,'raster_images':0})
  doc.insert_pdf(src)
doc.set_metadata({'title':'Fruchter House — Shared Ground','subject':'Rotation, overlap and interior refinement / shared office study','author':'장승환 / spatial reconstruction study','keywords':'Fruchter House, figure-ground, shared office, rotation, interstice'})
doc.set_toc([[1,p.stem.replace('_',' '),i+1] for i,p in enumerate(PAGES)])
pdf=ROOT/'Fruchter_Shared_Ground_Final_A2.pdf'
if pdf.exists():pdf.unlink()
doc.save(pdf,garbage=4,deflate=True)
sheet=Image.new('RGB',(1800,2696),'#E7E8EA');draw=ImageDraw.Draw(sheet)
for i,page in enumerate(doc):
 pix=page.get_pixmap(matrix=fitz.Matrix(900/page.rect.width,900/page.rect.width),alpha=False)
 im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
 x=(i%2)*900;y=(i//2)*674;sheet.paste(im,(x,y));draw.text((x+18,y+644),PAGES[i].stem,fill='#283858')
sheet.save(ROOT/'Fruchter_Final_Overview.png')
doc.close()

for p in OUT.glob('*.svg'):
 root=ET.parse(p).getroot();ids=[n.get('id') for n in root.iter() if n.get('id')]
 assert len(ids)==len(set(ids)),p
 for n in root.iter('{'+NS+'}text'):
  assert all(ord(c) in FM[n.get('data-font','KR')]['cmap'] for c in n.text or ''),(p,n.text)

for p in (ROOT/'review').glob('*-text-bounds.json'):
 for t in json.loads(p.read_text()):
  assert 17.9<=t['left'] and t['right']<=576.1 and t['baseline']<=414.1,(p.name,t)

report={'pdf_pages':7,'page_checks':checks,'svg_unique_ids':True,'font_glyphs_present':True,'text_inside_margins':True,'geometry':json.loads((ROOT/'design/validation.json').read_text())}
(ROOT/'design/export-checks.json').write_text(json.dumps(report,indent=2))
files=[]
for folder in ['scripts','assets','design','output']:
 files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
files.extend(ROOT/n for n in ['README.md','DESIGN_PHILOSOPHY.md','requirements.txt','Fruchter_Shared_Ground_Final_A2.pdf','Fruchter_Final_Overview.png'])
manifest={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(files)}
(ROOT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2));files.append(ROOT/'MANIFEST.json')
archive=ROOT/'Fruchter_Shared_Ground_Editable.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,'Fruchter_Shared_Ground/'+str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'pdf_bytes':pdf.stat().st_size,'zip_bytes':archive.stat().st_size,'zip_files':len(files),'pages':7}))
