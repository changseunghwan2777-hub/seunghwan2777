from draw import *
from selected import C
from shapely.ops import nearest_points
from shapely.prepared import prep
import heapq, hashlib, csv

ROOT=Path(__file__).resolve().parents[1]
OLD=C['floor']
OLD_H=[Polygon(r) for r in OLD.interiors]
NEW_H=[p.convex_hull if p.convex_hull.area-p.area>1e-6 else p for p in OLD_H]
OUTER=Polygon(OLD.exterior)
FLOOR=OUTER.difference(unary_union(NEW_H))
CUT=OLD.difference(FLOOR)
OVER=C['overlap'].intersection(FLOOR)
TRIPLE=C['triples'].intersection(FLOOR)
H=json.loads((ROOT/'design/hatch-paths.json').read_text())
NAVY='#283858';ROSE='#BD6174';MAGENTA='#D52B82';PALE='#F7DCE9';MUTED='#727782';INK='#18202C'
FRAME=unary_union([OLD,build_field('BASE',0)['floor']]).envelope
changed=[i for i,(a,b) in enumerate(zip(OLD_H,NEW_H)) if b.area-a.area>1e-6]

def strokegeom(b,g,T,color='#FFF',lw=.1,dash=None):
 for l in lines(g):b.path([T(p) for p in l.coords],None,color,lw,dash,False)

def head(b,num,title,kr):
 b.layer('00_Titles')
 b.text(18,17,'FRUCHTER HOUSE / SPATIAL RECONSTRUCTION / SHARED OFFICE STUDY',8.4,'EN',MUTED)
 b.text(576,17,f'{num:02d} / 07',10,'EN',MAGENTA,'end')
 b.text(18,34,title,30,'EN',INK)
 b.text(18,46,kr,11.2,'KR',INK)
 b.line((18,55),(576,55),'#BFC4CC',.2)

def foot(b,note='설계 스터디 / u는 상대 단위 / 실제 치수·구조·층고는 확정하지 않음.'):
 b.layer('99_Footer');b.line((18,406),(576,406),'#D5D8DD',.18)
 b.text(18,414,note,7.2,'KR',MUTED)
 b.text(576,414,'A2 / 594 × 420 mm / NTS',7.2,'EN',MUTED,'end')

def caption(b,x,y,k,title,body,w=100):
 b.text(x,y,k,9,'EN',MAGENTA);b.text(x,y+8,title,11,'KR',INK)
 b.wrap(x,y+17,body,w,9,5,MUTED)

def hatchplot(b,T):
 for kind in ['A','B','C']:
  b.layer('Hatch_'+kind)
  for h in H:
   if h['kind']==kind:strokegeom(b,LineString(h['pts']).intersection(FLOOR),T,'#242424',.2*h['weight'])
 b.layer('Overlap_edges');drawgeom(b,OVER,T,None,'#454545',.09)
 b.layer('Cleaned_void_edges')
 for i in changed:drawgeom(b,NEW_H[i],T,None,'#454545',.09)

def route_geometry():
 cache=ROOT/'design/routes.json'
 if cache.exists():return [LineString(p) for p in json.loads(cache.read_text())]
 safe=FLOOR.buffer(-.085,join_style=2)
 assert len(polys(safe))==1
 # Visibility paths inside an inset floor; this is a spatial proposal, not an exit plan.
 requested=[(-3.9,-.15),(3.95,1.9),(-1.9,2.8),(1.1,-2.1)]
 goals=[]
 for q in requested:
  p=Point(q)
  if not safe.contains(p):p=nearest_points(safe.buffer(-.002),p)[0]
  goals.append(tuple(p.coords[0]))
 nodes=goals+[tuple(p) for r in [safe.exterior,*safe.interiors] for p in list(r.coords)[:-1]]
 test=prep(safe.buffer(1e-8));graph=[[] for p in nodes]
 for i in range(len(nodes)):
  for j in range(i):
   s=LineString([nodes[i],nodes[j]])
   if test.covers(s):
    graph[i].append((j,s.length));graph[j].append((i,s.length))
 def path(start,end):
  ds={start:0};prev={};q=[(0,start)]
  while q:
   d,i=heapq.heappop(q)
   if d>ds[i]:continue
   if i==end:break
   for j,w in graph[i]:
    if d+w<ds.get(j,1e30):ds[j]=d+w;prev[j]=i;heapq.heappush(q,(d+w,j))
  ids=[end]
  while ids[-1]!=start:ids.append(prev[ids[-1]])
  return LineString([nodes[i] for i in ids[::-1]])
 paths=[path(0,1),path(2,3)]
 cache.write_text(json.dumps([list(p.coords) for p in paths]))
 return paths

ROUTES=route_geometry()
RIBBON=unary_union([l.buffer(.065,join_style=2) for l in ROUTES]).intersection(FLOOR)

def colorplot(b,T,context=None,show_routes=True):
 clip=lambda g:g if context is None else g.intersection(context)
 b.layer('01_Continuous_office_floor');drawgeom(b,clip(FLOOR),T,NAVY)
 b.layer('02_Actual_overlap');drawgeom(b,clip(OVER),T,ROSE)
 b.layer('03_Triple_overlap');drawgeom(b,clip(TRIPLE),T,'#923653')
 b.layer('04_Module_and_wing_traces')
 for u in C['units']:
  for g in u['wings'].values():strokegeom(b,clip(g.boundary.intersection(FLOOR)),T,'#DAE0EC',.10)
 b.layer('05_Court_edges');drawgeom(b,clip(unary_union(NEW_H)),T,None,NAVY,.12)
 if show_routes:
  b.layer('06_Proposed_shared_connection');drawgeom(b,clip(RIBBON),T,MAGENTA)
  for l in ROUTES:strokegeom(b,clip(l),T,'#FBE5F0',.16)

def process():
 b=Board('01_Process');head(b,1,'ROTATION MAKES ROOM','같은 모듈의 다른 방향이 중첩을 만들고, 경계의 정리가 공간을 명료하게 한다.')
 base=build_field('BASE',0)
 stages=[base['floor'],OLD,OLD,FLOOR,FLOOR]
 titles=['반복의 출발점','독립 중심의 회전','중첩과 비움','내부 경계 정리','공유 바닥으로 읽기']
 bodies=['세 날개 모듈을 엇갈린 격자에 놓는다. 중심 중정은 각 모듈에 유지한다.','20개 중심의 위치와 각도를 같은 함수로 바꾼다. 반복은 유지하고 만남은 달라진다.','이웃 모듈의 교집합과 사이에 남는 빈 공간을 함께 읽는다.','내부 9곳의 돌출부를 덜어낸다. 외곽·위치·회전각은 그대로 둔다.','겹침은 공유 영역, 나머지는 업무 바탕으로 해석한다. 비움은 계속 열어 둔다.']
 for i,g in enumerate(stages):
  x=18+113*i;T=fit(FRAME,x,78,106,125)
  if i==4:colorplot(b,T,show_routes=False)
  else:
   drawgeom(b,g,T,'#B4BBC7' if i in [1,2] else '#18202C')
   if i==2:drawgeom(b,OVER,T,ROSE);drawgeom(b,CUT,T,MAGENTA)
  if i<4:b.arrow([(x+104,139),(x+110,139)],'#ADB3BC',.2,1)
  caption(b,x,219,f'0{i+1}',titles[i],bodies[i],102)
 b.line((18,274),(576,274),'#D5D8DD',.2)
 T=fit(ENVELOPE,20,294,132,91)
 for k,g in BASE.items():drawgeom(b,g,T,'#DCE1E9',NAVY,.22)
 drawgeom(b,COURT,T,'#FFF',NAVY,.22)
 b.text(18,395,'M4 / 세 날개 + 중앙 비움',9)
 b.text(177,297,'ONE MOTIF / TWENTY CENTRES',19,'EN',NAVY)
 b.wrap(177,312,'Fruchter House에서 출발한 공간군의 독립성과 방향 관계를 세 날개의 연구 모듈로 추상화했다. 반복하는 것은 이 연구 모듈이며 원본 주택의 실측 평면은 아니다.',174,10,6)
 b.text(177,365,'20',36,'EN',NAVY);b.text(204,365,'개 모듈',10)
 b.text(280,365,'31',36,'EN',NAVY);b.text(307,365,'개 내부 비움',10)
 b.text(177,387,'20개 모듈 중정 + 11개 사이 공간',10)
 b.text(388,297,'EDIT THE EDGE, KEEP THE FIELD',16,'EN',NAVY)
 b.wrap(388,312,'최종 정리는 새로운 군집이나 중심 다각형을 만드는 조작이 아니다. 승인된 하나의 배치에서 안쪽으로 들어온 돌출부만 제거해, 중첩의 결과를 더 분명하게 읽는다.',185,10,6)
 b.text(388,365,'1.40%',32,'EN',MAGENTA);b.text(388,381,'정리 과정에서 덜어낸 기존 바닥 면적',9.5)
 foot(b,'관찰: 서로 다른 방향의 공간군 / 설계 제안: M4 모듈·반복·회전 규칙·내부 경계 정리·공용 오피스 해석.');b.save()

def rule():
 b=Board('02_Rotation_Rule');head(b,2,'TWENTY PIVOTS, ONE RULE','서로 다른 중심에서 움직이되, 두 기준점에 대한 반응으로 전체 배치를 조절한다.')
 for n,a in enumerate([0,.5,1]):
  field=build_field('COUNTER',a);x=18+n*188;T=fit(FRAME,x,83,176,157)
  drawgeom(b,field['floor'],T,'#D6DBE4');drawgeom(b,field['overlap'],T,ROSE)
  for u in field['units']:
   b.cross(*T(u['pivot']),.9,NAVY,.16)
   p=T(u['pivot']);r=4;ang=math.radians(-u['angle'])
   b.line(p,(p[0]+r*math.cos(ang),p[1]+r*math.sin(ang)),NAVY,.24)
  if n>0:
   for u in field['units']:
    if (u['i']+u['j'])%3==0:b.arrow([T(u['q']),T(u['pivot'])],MAGENTA,.2,1)
  b.text(x,72,f'0{n+1} / ROTATION FACTOR {a:.1f}',10,'EN',NAVY)
  b.text(x,253,['시작 / 같은 각도','중간 / 변화량의 절반','선정 / 승인된 배열'][n],12)
  b.text(x,264,f"모듈 각도 {field['metrics']['min_angle']:.1f}° ~ {field['metrics']['max_angle']:.1f}°",9)
 b.line((18,280),(576,280),'#D5D8DD',.2)
 b.text(18,299,'θ(q) = 44°a (w1 − w2) + 6°a q_y',18,'EN',NAVY)
 b.text(18,312,'w_k = exp[−|q − F_k|² / (2 × 2.5²)]',12,'EN',NAVY)
 b.wrap(18,329,'F1 = (−2.4, 0), F2 = (2.4, 0). 두 점의 영향은 반대 방향으로 작용한다. 각 모듈은 이동한 자신의 중심 P에서 θ만큼 회전한다.',260,10,6)
 b.wrap(18,363,'위치 P는 두 기준점 주위의 가중 회전 변위에 0.62를 곱해 원래 격자 위치 q에 더한다. 동일한 규칙이 위치와 방향의 연속적인 차이를 만든다.',260,10,6)
 b.text(316,299,'WHAT STAYS / WHAT CHANGES',16,'EN',NAVY)
 b.wrap(316,316,'유지: 세 날개 형태, 모듈 중정, 20개 모듈의 개수.\n변화: 중심 위치, 전체 모듈 각도, 이웃과의 교집합.\n최종 정리: 선정된 위치·각도를 고정한 뒤 내부 경계만 절삭.',254,11,7)
 b.text(316,361,'검정 축선 = 모듈 방향 / 마젠타 화살표 = 중심 이동',9)
 b.text(316,375,'세 단계는 같은 방향·축척. 최종 지도의 배치는 a = 1.0.',9)
 foot(b,'회전 계수 a와 모든 좌표는 설계 변수. 원본 Fruchter House에서 확인된 치수나 각도로 주장하지 않는다.');b.save()

def cleanup_board():
 b=Board('03_Interior_Refinement');head(b,3,'REFINE THE INSIDE','외곽을 바꾸지 않고, 내부의 작은 돌출과 불필요한 꺾임만 정리한다.')
 for n,g in enumerate([OLD,FLOOR]):
  x=18+288*n;T=fit(OLD,x,78,268,174);drawgeom(b,g,T,NAVY)
  if n==0:drawgeom(b,CUT,T,MAGENTA)
  b.text(x,69,['BEFORE / 제거 대상 표시','AFTER / 승인된 내부 정리'][n],10)
  b.text(x,262,['마젠타: 내부 빈 공간에 돌출된 기존 바닥','외곽·20개 중심·회전각·모듈 중정 유지'][n],9)
 indices=sorted(changed,key=lambda i:NEW_H[i].area-OLD_H[i].area,reverse=True)[:3]
 for n,i in enumerate(indices):
  x=18+n*188;c=NEW_H[i].centroid;window=box(c.x-.6,c.y-.53,c.x+.6,c.y+.53);T=fit(window,x,281,110,100)
  drawgeom(b,OLD.intersection(window),T,NAVY);drawgeom(b,CUT.intersection(window),T,MAGENTA)
  strokegeom(b,NEW_H[i].boundary,T,'#FFF',.3)
  b.text(x+119,296,f'0{n+1}',14,'EN',MAGENTA)
  b.wrap(x+119,308,['꺾인 경계를\n한 번에 연결','작은 돌출부를\n비움으로 환원','뾰족한 끝을\n직선으로 정리'][n],56,10,6)
  b.wrap(x+119,341,'주변 꼭짓점을 잇는 최소 볼록 경계로 정리.',56,9,5)
 b.text(18,395,'9곳 수정 / 기존 검정 면의 1.40% 제거 / 31개 내부 비움 유지 / 하나의 바닥 연결 유지',10)
 foot(b,'위 두 지도는 같은 축척, 아래 세 확대도는 서로 같은 축척. 마젠타 면적은 제거량이며 새로운 실내 프로그램이 아니다.');b.save()

def hero(mode,clean=False):
 names={'black':'04_Figure_Ground','line':'05_Directional_Hatch','color':'06_Colored_Figure_Ground'}
 b=Board(('Clean_'+mode.title()) if clean else names[mode])
 if not clean:
  head(b,{'black':4,'line':5,'color':6}[mode],{'black':'ONE CONTINUOUS GROUND','line':'DIRECTIONS IN OVERLAP','color':'A MAP OF SHARED GROUND'}[mode],{'black':'검정은 공유 영역을 포함한 실내 바닥, 흰색은 중정·사이 공간·외부를 나타낸다.','line':'세 날개의 선 방향에 각 모듈의 회전각이 더해져, 겹침의 위치와 밀도가 드러난다.','color':'인디고의 업무 바탕 위에 실제 중첩과 제안 동선을 겹쳐 공용 오피스의 관계를 읽는다.'}[mode])
 T=fit(OLD,35,30 if clean else 65,524,360 if clean else 303)
 if mode=='black':drawgeom(b,FLOOR,T,'#111')
 elif mode=='line':hatchplot(b,T)
 else:colorplot(b,T)
 if not clean:
  b.layer('Legend');b.line((18,377),(576,377),'#D5D8DD',.2)
  if mode=='color':
   legends=[(18,NAVY,'업무 바탕'),(118,ROSE,'두 모듈 중첩'),(231,'#923653','세 모듈 중첩'),(344,MAGENTA,'제안 공유 연결'),(466,'#FFF','중정·외부 비움')]
   for x,color,s in legends:b.rect(x,385,6,5,color,NAVY,.15);b.text(x+10,389,s,9.4)
   foot(b,'색은 공간 해석의 레이어. 가는 선은 모듈·날개 경계의 흔적이며 벽체가 아니다. 연결 띠의 폭은 도식적이다.')
  else:
   b.text(18,389,'20 MODULES',12,'EN',NAVY);b.text(209,389,'31 ENCLOSED VOIDS',12,'EN',NAVY);b.text(433,389,'1 CONNECTED FLOOR',12,'EN',NAVY)
   foot(b,'04–06은 동일 배치·방향·축척. 검정 면은 실내 바닥 영역이며 벽체 포셰 또는 시공 도면을 뜻하지 않는다.')
 b.save()

def office():
 b=Board('07_Office_Reading');head(b,7,'FROM OVERLAP TO SHARED USE','형태의 결과에 용도를 덧붙인다. 중정은 비워 두고, 겹침은 함께 쓰는 장소로 해석한다.')
 T=fit(OLD,18,77,254,218);colorplot(b,T)
 chosen=[('A','22','32','넓은 중첩 / 공동 작업','서로 다른 업무 방향이 만나는 넓은 교집합. 공동 테이블이나 짧은 팀 협의의 후보로 읽는다.'),('B','23','34','사선 접합 / 교류와 전환','서로 다른 축 사이에서 방향이 전환된다. 업무 영역 사이의 공유 라운지나 전환 장소로 검토한다.'),('C','13','14','중정 주변 / 업무와 휴식','비움을 유지하면서 주변의 공유 영역을 사용한다. 채광·시선·업무 간 거리를 후속 평면에서 검토한다.')]
 for n,(tag,a,c,title,desc) in enumerate(chosen):
  contact=next(g for g in C['contacts'] if g['a']==a and g['b']==c)
  g=contact['geometry'].intersection(FLOOR);p=maximum_inscribed_circle(max(polys(g),key=lambda q:q.area),tolerance=.001).coords[0]
  b.circle(*T(p),3,'#FFF',MAGENTA,.25);b.text(T(p)[0],T(p)[1]+1,tag,9,'EN',MAGENTA,'middle')
  y=78+n*105;window=box(p[0]-1.1,p[1]-.65,p[0]+1.1,p[1]+.65);Z=fit(window,300,y,130,82)
  colorplot(b,Z,window)
  b.text(444,y+7,tag,18,'EN',MAGENTA);b.text(444,y+18,title,10)
  b.wrap(444,y+31,desc,128,9.5,5.7)
  b.text(444,y+76,f'모듈 {a} + {c} / 확대도 동일 축척',8,'KR',MUTED)
 b.text(18,316,'THE COURTS REMAIN EMPTY',17,'EN',NAVY)
 b.wrap(18,332,'20개 모듈 중정과 11개 사이 공간은 그대로 비워 둔다. 마젠타 연결 띠는 중정을 가로지르지 않고 실내 바닥을 따라 두 방향의 공유 흐름을 제안한다.',250,10.5,6.2)
 b.wrap(18,367,'중첩의 면적과 방향은 기하학적 결과다. 공동 작업·라운지·휴식은 그 결과를 공용 오피스로 읽기 위한 프로그램 가설이다.',250,10,6)
 foot(b,'프로그램·연결 띠는 설계 제안. 실치수·가구·문·피난·접근성은 후속 건축 평면에서 검토할 항목.');b.save()

def audit():
 from shapely.geometry import mapping
 assert FLOOR.is_valid and len(polys(FLOOR))==1 and len(FLOOR.interiors)==31
 assert Polygon(FLOOR.exterior).equals(OUTER)
 assert all(p.intersection(FLOOR).area<1e-9 for p in C['courts'].geoms)
 assert RIBBON.difference(FLOOR).area<1e-9
 assert all(FLOOR.covers(l) for l in ROUTES)
 a=dict(modules=20,voids=31,changed_voids=len(changed),connected_floor=True,exterior_preserved=True,removed_area=CUT.area,removed_percent=100*CUT.area/OLD.area,overlap_area=OVER.area,overlap_percent=100*OVER.area/FLOOR.area,normalized_unit='u; not metres')
 (ROOT/'design/validation.json').write_text(json.dumps(a,indent=2))
 (ROOT/'design/final-geometry.geojson').write_text(json.dumps({'type':'FeatureCollection','features':[{'type':'Feature','properties':{'layer':name},'geometry':mapping(g)} for name,g in [('floor',FLOOR),('overlap',OVER),('courts',C['courts']),('removed',CUT),('proposed_connection',RIBBON)]]}))
 with (ROOT/'design/pivots.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['module','pivot_x_u','pivot_y_u','angle_degrees'])
  for u in C['units']:w.writerow([u['id'],u['x'],u['y'],u['angle']])
 print(json.dumps(a))

if __name__=='__main__':
 import sys
 audit()
 if '--color-only' in sys.argv:hero('color');hero('color',True)
 else:
  process();rule();cleanup_board()
  for mode in ['black','line','color']:hero(mode)
  office()
  for mode in ['black','line','color']:hero(mode,True)
