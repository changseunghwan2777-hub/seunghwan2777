"""Fruchter House — controlled rotation study for Rhino 8 / Python 3.

Run in Rhino 8 ScriptEditor using Python 3. Geometry is planar and NTS.
One model coordinate unit represents U, the original A inward-edge length;
it is NOT one metre or one millimetre. Document units are never changed.
The script was syntax-checked in the cloud. Rhino execution was not available.

Operation order: rotate each original group at its authored pivot, apply the
fixed translation, mirror source y-down to Rhino y-up, normalize by U.
Compare R0-R3. Only angle changes; source footprint areas remain identical.
"""

# ── PARAMETERS: change these values to study a different rotation ─────────
ANGLE_SETS = {"R0": {"A": 0, "B": 0, "C": 0},
              "R1": {"A": -8, "B": 8, "C": -5},
              "R2": {"A": -14, "B": 18, "C": 10},
              "R3": {"A": -22, "B": 24, "C": -18}}
SHOW_ALL_VARIANTS = True
SELECTED_VARIANT = "R2"
DISPLAY_SPACING_U = 4.5
DRAW_TRANSLATED_CONTROL = True
PROJECT_PREFIX = "Fruchter_Rotation"
# Positive angle means clockwise on the original sheet, not Rhino XY.
PIVOTS = {'A': [349.5, 268], 'B': [461.5, 267], 'C': [371.5, 426.5]}
FIXED_TRANSLATIONS = {'A': [-40, -12], 'B': [109, -25], 'C': [-40, 65]}
U = 224.26992665089986
# ─────────────────────────────────────────────────────────────────────────

import math
import Rhino
import Rhino.Geometry as rg
import scriptcontext as sc
from System.Drawing import Color

ORIGINAL = {'A': [[235, 57], [399, 205], [260, 381], [76, 247]], 'B': [[437, 211], [651, 123], [739, 324], [525, 412]], 'C': [[276, 413], [502, 444], [463, 675], [239, 642]]}
HEARTH = [[416, 376], [480, 294], [519, 393]]

def layer_index(name, colour):
    index = sc.doc.Layers.FindByFullPath(name, -1)
    if index < 0:
        layer = Rhino.DocObjects.Layer()
        layer.Name = name
        layer.Color = colour
        index = sc.doc.Layers.Add(layer)
    return index

def attributes(layer, name):
    result = Rhino.DocObjects.ObjectAttributes()
    result.LayerIndex = layer
    result.Name = name
    result.SetUserString("Scale", "NTS: 1 model unit = U, not metres")
    result.SetUserString("Claim", "Design proposal; rotation-only controlled comparison")
    return result

def point_xy(source_point, horizontal_offset_u=0):
    return rg.Point3d(source_point[0]/U+horizontal_offset_u, -source_point[1]/U, 0)

def transformed_curve(group, angle, offset):
    points = [point_xy(p) for p in ORIGINAL[group]]
    curve = rg.PolylineCurve(points + [points[0]])
    # The y-up Rhino coordinate system reverses the sign of sheet rotation.
    pivot = point_xy(PIVOTS[group])
    curve.Transform(rg.Transform.Rotation(-math.radians(angle),rg.Vector3d.ZAxis,pivot))
    dx,dy = FIXED_TRANSLATIONS[group]
    curve.Transform(rg.Transform.Translation(rg.Vector3d(dx/U+offset,-dy/U,0)))
    return curve

def add_reference_axis(group, angle, offset, layer):
    pivot = point_xy(PIVOTS[group])
    original_points = ORIGINAL[group]
    # An explicit visual axis, not an inferred structural grid.
    centre = [sum(p[i] for p in original_points)/len(original_points) for i in (0,1)]
    line = rg.LineCurve(pivot, point_xy(centre))
    line.Transform(rg.Transform.Rotation(-math.radians(angle),rg.Vector3d.ZAxis,pivot))
    dx,dy = FIXED_TRANSLATIONS[group]
    line.Transform(rg.Transform.Translation(rg.Vector3d(dx/U+offset,-dy/U,0)))
    sc.doc.Objects.AddCurve(line, attributes(layer,group+" proposed directional axis"))
    p = point_xy([PIVOTS[group][0]+dx,PIVOTS[group][1]+dy],offset)
    sc.doc.Objects.AddPoint(p,attributes(layer,group+" fixed translated pivot"))

def build():
    keys=list(ANGLE_SETS) if SHOW_ALL_VARIANTS else [SELECTED_VARIANT]
    colours={"A":Color.FromArgb(85,103,94),"B":Color.FromArgb(71,121,137),"C":Color.FromArgb(104,138,104)}
    created=[]
    for n,key in enumerate(keys):
        offset=n*DISPLAY_SPACING_U
        control_layer=layer_index(PROJECT_PREFIX+"_"+key+"_Control",Color.FromArgb(185,190,183))
        axis_layer=layer_index(PROJECT_PREFIX+"_"+key+"_Axes",Color.FromArgb(174,91,53))
        for group in ("A","B","C"):
            group_layer=layer_index(PROJECT_PREFIX+"_"+key+"_"+group,colours[group])
            curve=transformed_curve(group,ANGLE_SETS[key][group],offset)
            if not curve.IsValid or not curve.IsClosed:
                raise RuntimeError("Invalid authored curve: "+key+"/"+group)
            created.append(sc.doc.Objects.AddCurve(curve,attributes(group_layer,key+"/"+group)))
            if DRAW_TRANSLATED_CONTROL:
                control=transformed_curve(group,0,offset)
                sc.doc.Objects.AddCurve(control,attributes(control_layer,key+"/"+group+" translated control"))
            add_reference_axis(group,ANGLE_SETS[key][group],offset,axis_layer)
        h=[point_xy(p,offset) for p in HEARTH]
        hearth_layer=layer_index(PROJECT_PREFIX+"_"+key+"_Hearth",Color.Black)
        sc.doc.Objects.AddCurve(rg.PolylineCurve(h+[h[0]]),attributes(hearth_layer,"Retained hearth position reference"))
        sc.doc.Objects.AddTextDot(rg.TextDot(key+" / NTS, 1 unit = U",rg.Point3d(offset,0.25,0)),attributes(axis_layer,key+" label"))
    sc.doc.Views.Redraw()
    print("Created",len(created),"closed group curves. Only rotation varies across the translated study frame.")
    print("U is a relative source-sketch length. Model-unit labels are not a real building scale.")
    return created

if __name__ == "__main__":
    build()
