# Rhino 8 / Grasshopper 실행 안내

- `rotation_study_rhino8.py`: Rhino 8의 ScriptEditor에서 Python 3로 실행합니다. R0~R3를 나란히 그립니다. 파일 상단의 각도, 선택안, 표시 간격을 수정할 수 있습니다.
- `rotation_ghpython.py`: Grasshopper의 Python 3 컴포넌트에 붙여 넣습니다. 입력 `angle_a`, `angle_b`, `angle_c`는 Item Access 숫자이며 기본값은 -14, +18, +10입니다. 출력은 `groups`, `controls`, `pivot_points`, `notes`입니다.
- 회전축과 이격량은 고정하고 각도만 변경합니다. 입력 스케치는 y축 아래 방향, Rhino는 y축 위 방향이므로 회전 부호와 y좌표를 변환합니다.
- 모델 수치 1은 U(원본 A 중심 측 변 길이)입니다. 실제 미터·밀리미터로 환산하지 않았으며 문서 단위를 자동 변경하지 않습니다.
- 여기서 만든 것은 평면 곡선입니다. 높이·지붕·구조를 임의로 추가하지 않았습니다.
- 이 클라우드 환경에는 Rhino 8 / RhinoCommon 실행 환경이 없어 **Python 문법 검사만 완료**했습니다. Rhino·Grasshopper 내 실행은 확인하지 않았습니다. HTML·PDF·SVG 결과물은 별도로 실행·검사했습니다.
- Grasshopper에서 임의의 각도로 변경한 결과는 검토된 R0~R3와 다를 수 있습니다. 겹침·유효 통로·프로그램 관계를 다시 확인해야 합니다.
