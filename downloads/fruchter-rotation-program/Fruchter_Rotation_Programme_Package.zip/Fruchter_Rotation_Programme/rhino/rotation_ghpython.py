"""Component: Fruchter Rotation Study / Rhino 8 Python 3
Inputs (Item Access):
    angle_a (float): Clockwise sheet rotation for A, default -14 degrees.
    angle_b (float): Clockwise sheet rotation for B, default +18 degrees.
    angle_c (float): Clockwise sheet rotation for C, default +10 degrees.
Outputs:
    groups (list[Curve]): Three closed footprint curves, in A/B/C order.
    controls (list[Curve]): Translated zero-rotation control curves.
    pivot_points (list[Point3d]): Fixed pivots after translation.
    notes (str): Unit and assumption statement.
Geometry is unitless: 1 model coordinate unit = U, not one metre.
No baking or scene deletion is performed. Cloud check: Python syntax only.
"""
import math
import Rhino.Geometry as rg

PIVOTS = {'A': [349.5, 268], 'B': [461.5, 267], 'C': [371.5, 426.5]}
SHIFTS = {'A': [-40, -12], 'B': [109, -25], 'C': [-40, 65]}
U = 224.26992665089986
ORIGINAL = {'A': [[235, 57], [399, 205], [260, 381], [76, 247]], 'B': [[437, 211], [651, 123], [739, 324], [525, 412]], 'C': [[276, 413], [502, 444], [463, 675], [239, 642]]}

def value(name, default):
    v=globals().get(name,default)
    return default if v is None else float(v)

angles={"A":value("angle_a",-14),"B":value("angle_b",18),"C":value("angle_c",10)}
groups=[]
controls=[]
pivot_points=[]
for k in ("A","B","C"):
    points=[rg.Point3d(p[0]/U,-p[1]/U,0) for p in ORIGINAL[k]]
    control=rg.PolylineCurve(points+[points[0]])
    curve=control.DuplicateCurve()
    pivot=rg.Point3d(PIVOTS[k][0]/U,-PIVOTS[k][1]/U,0)
    curve.Transform(rg.Transform.Rotation(-math.radians(angles[k]),rg.Vector3d.ZAxis,pivot))
    dx,dy=SHIFTS[k]
    shift=rg.Transform.Translation(rg.Vector3d(dx/U,-dy/U,0))
    curve.Transform(shift)
    control.Transform(shift)
    groups.append(curve)
    controls.append(control)
    pivot_points.append(rg.Point3d((PIVOTS[k][0]+dx)/U,-(PIVOTS[k][1]+dy)/U,0))
notes="NTS / 1 unit = U / fixed pivots and shifts / only angles vary / arbitrary slider values require overlap and programme review"
